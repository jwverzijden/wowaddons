DBM:RegisterMapSize("VaultofArchavon", 1, 1398.255004883, 932.170013428) -- Vault of Archavon
