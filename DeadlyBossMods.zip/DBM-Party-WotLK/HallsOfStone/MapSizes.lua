DBM:RegisterMapSize("Ulduar77", 1, 920.19794213868, 613.46401864487) -- Halls of Stone
