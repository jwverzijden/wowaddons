--[[
	OmniCC localization - koKR
--]]

if GetLocale() ~= 'koKR' then return end

local L = OMNICC_LOCALS

L.Updated = "v%s로 업데이트되었습니다."
L.None = NONE
L.Pulse = "맥박"
L.Shine = "반짝임"