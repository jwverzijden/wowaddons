--[[
	OmniCC localization - English
--]]

OMNICC_LOCALS = {} --should be done in the US locale file, only

local L = OMNICC_LOCALS
--[[
if not GetLocale() == 'enUS' then
	return
end
--]]

L.Updated = "Updated to v%s"
L.None = NONE
L.Pulse = "Pulse"
L.Shine = "Shine"