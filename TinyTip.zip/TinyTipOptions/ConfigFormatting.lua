local _G = getfenv(0)
local core = TinyTip
local L = _G.TinyTipOptionsLocale
local dropdown = LibStub("tekKonfig-Dropdown")
local check = LibStub("tekKonfig-Checkbox")
local db

local function keyName(tbl, name)
	for k, v in pairs(tbl) do
		if v == name then
			return L[k] or k
		end
	end
end

---------------------
--      Panel      --
---------------------

local frame = CreateFrame("Frame", nil, InterfaceOptionsFramePanelContainer)
frame.name = L["Opt_Main_Text"]
frame.parent = "TinyTip2"
frame:Hide()
frame:SetScript("OnShow", function(frame)
	db = core:GetDB()
	local title, subtitle = LibStub("tekKonfig-Heading").new(frame, L["Opt_Main_Text"])

	-- PvPRank
	local PvPRankTextDropdown, PvPRankTextDropdowntext, PvPRankTextDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_PvPRankText, "TOPLEFT", title, "BOTTOMLEFT", -2, -8)
	PvPRankTextDropdowntext:SetText(L.Map_PvPRankText[db.PvPRankText])
	PvPRankTextDropdown.tiptext = L.Desc_PvPRankText
	PvPRankTextDropdown:SetWidth(250)

	local function PvPRankTextOnClick(self)
		local value = keyName(L.Map_PvPRankText, self.value)
		UIDropDownMenu_SetSelectedValue(PvPRankTextDropdown, self.value)
		PvPRankTextDropdowntext:SetText(self.value)
		db.PvPRankText = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(PvPRankTextDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(PvPRankTextDropdown) or L.Map_PvPRankText[db.PvPRankText], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_PvPRankText) do
			info.text = v
			info.value = v
			info.func = PvPRankTextOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	local HideRace = check.new(frame, nil, L["Opt_HideRace"], "TOPLEFT", title, "BOTTOMLEFT", 230, -34)
	HideRace.tiptext = L["Desc_HideRace"]
	HideRace:SetScript("OnClick", function(self) db["HideRace"] = not db["HideRace"] end)
	HideRace:SetChecked(db["HideRace"])
	
	local HideNPCType = check.new(frame, nil, L["Opt_HideNPCType"], "LEFT", HideRace, "RIGHT", 115, 0)
	HideNPCType.tiptext = L["Desc_HideNPCType"]
	HideNPCType:SetScript("OnClick", function(self) db["HideNPCType"] = not db["HideNPCType"] end)
	HideNPCType:SetChecked(db["HideNPCType"])
	
	local KeyElite = check.new(frame, nil, L["Opt_KeyElite"], "TOPLEFT", title, "BOTTOMLEFT", -2, -68)
	KeyElite.tiptext = L["Desc_KeyElite"]
	KeyElite:SetScript("OnClick", function(self) db["KeyElite"] = not db["KeyElite"] end)
	KeyElite:SetChecked(db["KeyElite"])
	
	local ReactionText = check.new(frame, nil, L["Opt_ReactionText"], "LEFT", KeyElite, "RIGHT", 155, 0)
	ReactionText.tiptext = L["Desc_ReactionText"]
	ReactionText:SetScript("OnClick", function(self) db["ReactionText"] = not db["ReactionText"] end)
	ReactionText:SetChecked(db["ReactionText"])
	
	local LevelGuess = check.new(frame, nil, L["Opt_LevelGuess"], "LEFT", ReactionText, "RIGHT", 135, 0)
	LevelGuess.tiptext = L["Desc_LevelGuess"]
	LevelGuess:SetScript("OnClick", function(self) db["LevelGuess"] = not db["LevelGuess"] end)
	LevelGuess:SetChecked(db["LevelGuess"])
	
	local KeyServer = check.new(frame, nil, L["Opt_KeyServer"], "TOPLEFT", title, "BOTTOMLEFT", -2, -102)
	KeyServer.tiptext = L["Desc_KeyServer"]
	KeyServer:SetScript("OnClick", function(self) db["KeyServer"] = not db["KeyServer"] end)
	KeyServer:SetChecked(db["KeyServer"])


	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
