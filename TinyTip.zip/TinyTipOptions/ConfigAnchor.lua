local _G = getfenv(0)
local core = TinyTip
local L = _G.TinyTipOptionsLocale
local dropdown = LibStub("tekKonfig-Dropdown")
local slider = LibStub("tekKonfig-Slider")
local db

----------------------------
--      Initialising      --
----------------------------

local Map_MAnchor = {
	["GAMEDEFAULT"] = L.GameDefault,
	["CURSOR"] = L.CURSOR,
}
local Map_FAnchor = {
	["GAMEDEFAULT"] = L.GameDefault,
	["CURSOR"] = L.CURSOR,
	["SMART"] = L.SMART,
}
for k,v in pairs(L.Map_Anchor) do
	Map_MAnchor[k] = v
	Map_FAnchor[k] = v
end

local function keyName(tbl, name)
	for k, v in pairs(tbl) do
		if v == name then
			return L[k] or k
		end
	end
end

---------------------
--      Panel      --
---------------------

local frame = CreateFrame("Frame", nil, InterfaceOptionsFramePanelContainer)
frame.name = L["Opt_Main_Anchor"]
frame.parent = "TinyTip2"
frame:Hide()
frame:SetScript("OnShow", function(frame)
    db = core:GetDB()
	local title, subtitle = LibStub("tekKonfig-Heading").new(frame, L["Opt_Main_Anchor"])

	-- MainAnchor
	local MAnchorDropdown, MAnchorDropdowntext, MAnchorDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L["Opt_MAnchor"], "TOPLEFT", title, "BOTTOMLEFT", -2, -8)
	MAnchorDropdowntext:SetText(Map_MAnchor[db.MAnchor])
	MAnchorDropdown.tiptext = L.Desc_MAnchor
	MAnchorDropdown:SetWidth(170)

	local function MAnchorOnClick(self)
		UIDropDownMenu_SetSelectedValue(MAnchorDropdown, self.value)
		MAnchorDropdowntext:SetText(self.value)
		db.MAnchor = keyName(Map_MAnchor, self.value)
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(MAnchorDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(MAnchorDropdown) or Map_MAnchor[db.MAnchor], UIDropDownMenu_CreateInfo()

		for k, v in pairs(Map_MAnchor) do
			info.text = v
			info.value = v
			info.func = MAnchorOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)

	local MAnchorSliderX, MAnchorSliderXtext, MAnchorSliderXcontainer = slider.new(frame, L["Opt_MOffX"], -50, 50, "TOPLEFT", title, "BOTTOMLEFT", 168, -25)
	MAnchorSliderXcontainer:SetPoint("TOP", title, "TOP", 0, 0)
	MAnchorSliderX:SetValue(db.MOffX)
	MAnchorSliderX:SetValueStep(1)
	MAnchorSliderX:SetScript("OnValueChanged", function()
		db["MOffX"] = MAnchorSliderX:GetValue()
		MAnchorSliderXtext:SetText(db.MOffX)
	end)

	local MAnchorSliderY, MAnchorSliderYtext, MAnchorSliderYcontainer = slider.new(frame, L["Opt_MOffY"], -50, 50, "TOPLEFT", title, "BOTTOMLEFT", 338, -25)
	MAnchorSliderYcontainer:SetPoint("TOP", title, "TOP", 0, 0)
	MAnchorSliderY:SetValue(db.MOffY)
	MAnchorSliderY:SetValueStep(1)
	MAnchorSliderY:SetScript("OnValueChanged", function()
		db["MOffY"] = MAnchorSliderY:GetValue()
		MAnchorSliderYtext:SetText(db.MOffY)
	end)


	-- Frame Anchor
	local FAnchorDropdown, FAnchorDropdowntext, FAnchorDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L["Opt_FAnchor"], "TOPLEFT", title, "BOTTOMLEFT", -2, -68)
	FAnchorDropdowntext:SetText(Map_FAnchor[db.FAnchor])
	FAnchorDropdown.tiptext = L.Desc_FAnchor
	FAnchorDropdown:SetWidth(170)

	local function FAnchorOnClick(self)
		UIDropDownMenu_SetSelectedValue(FAnchorDropdown, self.value)
		FAnchorDropdowntext:SetText(self.value)
		db.FAnchor = keyName(Map_FAnchor, self.value)
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(FAnchorDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(FAnchorDropdown) or Map_FAnchor[db.FAnchor], UIDropDownMenu_CreateInfo()

		core:Debug(1, "selected: " .. selected)
		for k, v in pairs(Map_FAnchor) do
			info.text = v
			info.value = v
			info.func = FAnchorOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)

	local FAnchorSliderX, FAnchorSliderXtext, FAnchorSliderXcontainer = slider.new(frame, L["Opt_FOffX"], -50, 50, "TOPLEFT", title, "BOTTOMLEFT", 168, -85)
	FAnchorSliderXcontainer:SetPoint("TOP", title, "TOP", 0, 0)
	FAnchorSliderX:SetValue(db.FOffX)
	FAnchorSliderX:SetValueStep(1)
	FAnchorSliderX:SetScript("OnValueChanged", function()
		db["FOffX"] = FAnchorSliderX:GetValue()
		FAnchorSliderXtext:SetText(db.FOffX)
	end)

	local FAnchorSliderY, FAnchorSliderYtext, FAnchorSliderYcontainer = slider.new(frame, L["Opt_MOffY"], -50, 50, "TOPLEFT", title, "BOTTOMLEFT", 338, -85)
	FAnchorSliderYcontainer:SetPoint("TOP", title, "TOP", 0, 0)
	FAnchorSliderY:SetValue(db.FOffY)
	FAnchorSliderY:SetValueStep(1)
	FAnchorSliderY:SetScript("OnValueChanged", function()
		db["MOffY"] = FAnchorSliderY:GetValue()
		FAnchorSliderYtext:SetText(db.FOffY)
	end)

	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
