local _G = getfenv(0)
local L = _G.TinyTipOptionsLocale

---------------------
--      Panel      --
---------------------

local frame = CreateFrame("Frame", nil, InterfaceOptionsFramePanelContainer)
frame.name = "TinyTip2"
frame:Hide()
frame:SetScript("OnShow", function(frame)
	local title, subtitle = LibStub("tekKonfig-Heading").new(frame, "TinyTip", L["WhatIsTinyTip"])
	
	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
LibStub("tekKonfig-AboutPanel").new("TinyTip2", "TinyTip")
