local _G = getfenv(0)
local core = TinyTip
local L = _G.TinyTipOptionsLocale
local dropdown = LibStub("tekKonfig-Dropdown")
local check = LibStub("tekKonfig-Checkbox")
local db

local function keyName(tbl, name)
	for k, v in pairs(tbl) do
		if v == name then
			return L[k] or k
		end
	end
end

---------------------
--      Panel      --
---------------------

local frame = CreateFrame("Frame", nil, InterfaceOptionsFramePanelContainer)
frame.name = L["Opt_Main_Targets"]
frame.parent = "TinyTip2"
frame:Hide()
frame:SetScript("OnShow", function(frame)
	db = core:GetDB()
	local title, subtitle = LibStub("tekKonfig-Heading").new(frame, L["Opt_Main_Targets"])
	
	-- TargetsTooltipUnit
	local TargetsTooltipUnitDropdown, TargetsTooltipUnitDropdowntext, TargetsTooltipUnitDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_TargetsTooltipUnit, "TOPLEFT", title, "BOTTOMLEFT", 0, -8)
	TargetsTooltipUnitDropdowntext:SetText(L.Map_TargetsTooltipUnit[db.TargetsTooltipUnit])
	TargetsTooltipUnitDropdown.tiptext = L.Desc_TargetsTooltipUnit
	TargetsTooltipUnitDropdown:SetWidth(300)

	local function TargetsTooltipUnitOnClick(self)
		local value = keyName(L.Map_TargetsTooltipUnit, self.value)
		UIDropDownMenu_SetSelectedValue(TargetsTooltipUnitDropdown, self.value)
		TargetsTooltipUnitDropdowntext:SetText(self.value)
		db.TargetsTooltipUnit = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(TargetsTooltipUnitDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(TargetsTooltipUnitDropdown) or L.Map_TargetsTooltipUnit[db.TargetsTooltipUnit], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_TargetsTooltipUnit) do
			info.text = v
			info.value = v
			info.func = TargetsTooltipUnitOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	-- TargetsParty
	local TargetsPartyDropdown, TargetsPartyDropdowntext, TargetsPartyDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_TargetsParty, "TOPLEFT", title, "BOTTOMLEFT", 300, -8)
	TargetsPartyDropdowntext:SetText(L.Map_TargetsParty[db.TargetsParty])
	TargetsPartyDropdown.tiptext = L.Desc_TargetsParty
	TargetsPartyDropdown:SetWidth(200)

	local function TargetsPartyOnClick(self)
		local value = keyName(L.Map_TargetsParty, self.value)
		UIDropDownMenu_SetSelectedValue(TargetsPartyDropdown, self.value)
		TargetsPartyDropdowntext:SetText(self.value)
		db.TargetsParty = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(TargetsPartyDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(TargetsPartyDropdown) or L.Map_TargetsParty[db.TargetsParty], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_TargetsParty) do
			info.text = v
			info.value = v
			info.func = TargetsPartyOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	-- TargetsRaid
	local TargetsRaidDropdown, TargetsRaidDropdowntext, TargetsRaidDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_TargetsRaid, "TOPLEFT", title, "BOTTOMLEFT", 300, -78)
	TargetsRaidDropdowntext:SetText(L.Map_TargetsRaid[db.TargetsRaid])
	TargetsRaidDropdown.tiptext = L.Desc_TargetsRaid
	TargetsRaidDropdown:SetWidth(200)

	local function TargetsRaidOnClick(self)
		local value = keyName(L.Map_TargetsRaid, self.value)
		UIDropDownMenu_SetSelectedValue(TargetsRaidDropdown, self.value)
		TargetsRaidDropdowntext:SetText(self.value)
		db.TargetsRaid = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(TargetsRaidDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(TargetsRaidDropdown) or L.Map_TargetsRaid[db.TargetsRaid], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_TargetsRaid) do
			info.text = v
			info.value = v
			info.func = TargetsRaidOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	local TargetsNoEventUpdate = check.new(frame, nil, L["Opt_TargetsNoEventUpdate"], "TOPLEFT", TargetsTooltipUnitDropdown, "BOTTOMLEFT", 15, -35)
	TargetsNoEventUpdate.tiptext = L["Desc_TargetsNoEventUpdate"]
	TargetsNoEventUpdate:SetScript("OnClick", function(self) db["TargetsNoEventUpdate"] = not db["TargetsNoEventUpdate"] end)
	TargetsNoEventUpdate:SetChecked(db["TargetsNoEventUpdate"])


	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
