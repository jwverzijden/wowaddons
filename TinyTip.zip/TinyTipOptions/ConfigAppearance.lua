local _G = getfenv(0)
local core = TinyTip
local L = _G.TinyTipOptionsLocale
local dropdown = LibStub("tekKonfig-Dropdown")
local check = LibStub("tekKonfig-Checkbox")
local slider = LibStub("tekKonfig-Slider")
local db
if tekDebug then core:EnableDebug(1, tekDebug:GetFrame("TinyTip")) end

local function keyName(tbl, name)
	for k, v in pairs(tbl) do
		if v == name then
			return L[k] or k
		end
	end
end

--local Map_BGColor = L.Map_BGColor
--table.insert(Map_BGColor, 1, L.TinyTipDefault)

---------------------
--      Panel      --
---------------------

local frame = CreateFrame("Frame", nil, InterfaceOptionsFramePanelContainer)
frame.name = L["Opt_Main_Appearance"]
frame.parent = "TinyTip2"
frame:Hide()
frame:SetScript("OnShow", function(frame)
	db = core:GetDB()
	local title, subtitle = LibStub("tekKonfig-Heading").new(frame, L["Opt_Main_Appearance"])
	
	local ScaleSlider, ScaleSlidertext, ScaleSlidercontainer = slider.new(frame, L.Opt_Scale, 0.01, 1, "TOPLEFT", title, "BOTTOMLEFT", 7, -25)
	ScaleSlidercontainer:SetPoint("TOP", title, "TOP", 0, 0)
	ScaleSlider.tiptext = L.Desc_Scale
	ScaleSlider:SetValue(db.Scale)
	ScaleSlider:SetValueStep(0.01)
	ScaleSlider:SetScript("OnValueChanged", function()
		db.Scale = ScaleSlider:GetValue()
		ScaleSlidertext:SetText(db.Scale)
		core:ReInitialize()
	end)
	
	-- BGColor
	local BGColorDropdown, BGColorDropdowntext, BGColorDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_BGColor, "TOPLEFT", title, "BOTTOMLEFT", 177, -8)
	BGColorDropdowntext:SetText(L.Map_BGColor[db.BGColor])
	BGColorDropdown.tiptext = L.Desc_BGColor
	BGColorDropdown:SetWidth(200)

	local function BGColorOnClick(self)
		local value = keyName(L.Map_BGColor, self.value)
		UIDropDownMenu_SetSelectedValue(BGColorDropdown, self.value)
		BGColorDropdowntext:SetText(self.value)
		db.BGColor = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(BGColorDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(BGColorDropdown) or L.Map_BGColor[db.BGColor], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_BGColor) do
			info.text = v
			info.value = v
			info.func = BGColorOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	-- Border
	local BorderDropdown, BorderDropdowntext, BorderDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_Border, "BOTTOMLEFT", BGColorDropdown, "BOTTOMRIGHT", 0, 0)
	BorderDropdowntext:SetText(L.Map_Border[db.Border])
	BorderDropdown.tiptext = L.Desc_Border
	BorderDropdown:SetWidth(200)

	local function BorderOnClick(self)
		local value = keyName(L.Map_Border, self.value)
		UIDropDownMenu_SetSelectedValue(BorderDropdown, self.value)
		BorderDropdowntext:SetText(self.value)
		db.Border = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(BorderDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(BorderDropdown) or L.Map_Border[db.Border], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_Border) do
			info.text = v
			info.value = v
			info.func = BorderOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	-- ColourFriends
	local ColourFriendsDropdown, ColourFriendsDropdowntext, ColourFriendsDropdowncontainer = LibStub("tekKonfig-Dropdown").new(frame, L.Opt_ColourFriends, "TOPLEFT", title, "BOTTOMLEFT", 0, -75)
	ColourFriendsDropdowntext:SetText(L.Map_ColourFriends[db.ColourFriends])
	ColourFriendsDropdown.tiptext = L.Desc_ColourFriends
	ColourFriendsDropdown:SetWidth(200)

	local function ColourFriendsOnClick(self)
		local value = keyName(L.Map_ColourFriends, self.value)
		UIDropDownMenu_SetSelectedValue(ColourFriendsDropdown, self.value)
		ColourFriendsDropdowntext:SetText(self.value)
		db.ColourFriends = value
		core:ReInitialize()
	end
	UIDropDownMenu_Initialize(ColourFriendsDropdown, function()
		local selected, info = UIDropDownMenu_GetSelectedValue(ColourFriendsDropdown) or L.Map_ColourFriends[db.ColourFriends], UIDropDownMenu_CreateInfo()

		for k, v in pairs(L.Map_ColourFriends) do
			info.text = v
			info.value = v
			info.func = ColourFriendsOnClick
			info.checked = (v) == selected
			UIDropDownMenu_AddButton(info)
		end
	end)
	
	local HideInFrames = check.new(frame, nil, L["Opt_HideInFrames"], "BOTTOMLEFT", ColourFriendsDropdown, "BOTTOMRIGHT", 10, 5)
	HideInFrames.tiptext = L["Desc_HideInFrames"]
	HideInFrames:SetScript("OnClick", function(self) db["HideInFrames"] = not db["HideInFrames"] end)
	HideInFrames:SetChecked(db["HideInFrames"])
	
	local HideInCombat = check.new(frame, nil, L["Opt_HideInCombat"], "BOTTOMLEFT", ColourFriendsDropdown, "BOTTOMRIGHT", 235, 5)
	HideInCombat.tiptext = L["Desc_HideInCombat"]
	HideInCombat:SetScript("OnClick", function(self) db["HideInCombat"] = not db["HideInCombat"] end)
	HideInCombat:SetChecked(db["HideInCombat"])


	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
