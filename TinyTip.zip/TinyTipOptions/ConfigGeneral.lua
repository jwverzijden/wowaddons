----------------------
--      Locals      --
----------------------

local _G = getfenv(0)
local L = _G.TinyTipOptionsLocale
local core = TinyTip
local butt = LibStub("tekKonfig-Button")
local check = LibStub("tekKonfig-Checkbox")

---------------------
--      Panel      --
---------------------

local frame = CreateFrame("Frame", nil, InterfaceOptionsFramePanelContainer)
frame.name = L["Main_General"]
frame.parent = "TinyTip2"
frame:Hide()
frame:SetScript("OnShow", function(frame)
	local title, subtitle = LibStub("tekKonfig-Heading").new(frame, L["Main_General"])

	local resetdb = butt.new(frame, "TOPLEFT", title, "BOTTOMLEFT", 0, -12)
	resetdb:SetText(L["Opt_Main_Default"])
	resetdb.tiptext = L["Desc_Main_Default"]
	resetdb.name = L["Opt_Main_Default"]
	resetdb:SetWidth(100)
	resetdb:SetScript("OnClick", function() core.ResetDatabase() end)

	local profiles = check.new(frame, nil, L["Opt_Profiles"], "TOPLEFT", title, "BOTTOMLEFT", 110, -12)
	profiles.tiptext = L["Desc_Profiles"]
	profiles:SetScript("OnClick", function(self)
		core:ToggleSetProfile()
	end)
	if core:GetCurrentProfile() ~= "global" then
		profiles:SetChecked(true)
	else
		profiles:SetChecked(false)
	end

	frame:SetScript("OnShow", nil)
end)

InterfaceOptions_AddCategory(frame)
